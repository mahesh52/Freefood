<?php
date_default_timezone_set("Asia/Calcutta");
$db_name  = "freefood_freefood";   // The name of the database. 

$db_user  = "freefood_freefoo";   // Your MySQL username. You MUST create the user and pass yourself

$db_password  = "Fr@@2016";   // ...and password

$db_host  = "localhost";   // 99% chance you won't need to change this value

$connect = mysql_connect("$db_host","$db_user","$db_password");

$connection = mysql_select_db("$db_name",$connect);

?>